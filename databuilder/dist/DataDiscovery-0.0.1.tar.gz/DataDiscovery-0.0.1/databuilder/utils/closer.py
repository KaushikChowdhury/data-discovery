class Closer:

    def __init__(self):
        pass
